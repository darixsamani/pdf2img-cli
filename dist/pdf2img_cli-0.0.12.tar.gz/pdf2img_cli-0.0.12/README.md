# simpar-cli
this is cli for tranform pdf to images



## How to Install

```
pip install pdf2img-cli

```

## How to use


```
python3 -m pdf2img_cli --pdf ./example/examp.pdf --ouput ./img/

```

```
pdf2img_cli --pdf ./example/examp.pdf --ouput ./img/
```
 
